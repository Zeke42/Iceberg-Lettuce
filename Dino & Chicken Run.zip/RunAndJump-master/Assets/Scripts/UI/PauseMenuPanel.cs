﻿using UnityEngine;
using System.Collections;

namespace RunAndJump {

	public class PauseMenuPanel : MonoBehaviour {
		
	}

}
