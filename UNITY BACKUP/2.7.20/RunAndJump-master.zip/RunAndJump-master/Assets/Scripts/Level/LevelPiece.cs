﻿using UnityEngine;
using System.Collections;

namespace RunAndJump {
	public class LevelPiece : MonoBehaviour {

	}
}